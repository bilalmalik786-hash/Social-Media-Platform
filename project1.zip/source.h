#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <limits>
#include <sstream>
#include <cstdlib>
#include <cstddef>
#include <windows.h>
#include <algorithm> 

class User {
public:
     User(const std::string& username, const std::string& password, const std::string& interests, const std::string& location, const std::string& popularThings);

    std::string getUsername() const;
    std::string getPassword() const;
    std::string getInterests() const;
    std::string getLocation() const;
    std::string getPopularThings() const;
    void displayProfile() const;
    void connectWith(User& otherUser);
    void shareTextContent(const std::string& content);
    void shareImageContent(const std::string& imagePath);
    void receiveTextContent(const User& sender, const std::string& content);
    void postUpdate(const std::string& update);
    void setProfileDescription(const std::string& description);
    std::string getProfileDescription() const;
//    std::vector<User*> getFriends() const;
//    void addFriend(User* friendUser);
//    bool isFriend(User* user);
//    void discoverFriend(User* friendUser);
//    std::vector<User*> getAllFriends();
	 void setUsername(const std::string& username);
bool isString(const std::string& input);
    void setPassword(const std::string& password);

    void setInterests(const std::string& interests);

    void setLocation(const std::string& location);

    void setPopularThings(const std::string& popularThings);
    
    
    
    int getId() const;
    void setId(int value);
    
    
    void addFriend(User* user);
    void displayFriendList() const;
    std::vector<User*> getFriends()const;
     static int getIdCounter();
     static void setIdCounter(int value);
    
private:
    std::string username;
    std::string password;
    std::string interests;
    std::string location;
    std::string popularThings;
    std::string profileDescription;
   std::vector<User*> friends;
   
    friend class SocialMediaPlatform;
    
    static int idCounter;
    
    
    int id;
    
};


class Post {
public:
    Post(User* user, const std::string& content);

    User* getUser() const;

    void display();

    std::string getContent() const;

    void setContent(const std::string& newContent);

private:
    User* user;
    std::string content;
};




class SocialMediaPlatform {
public:
    void run();

private:
    void createUser();
    void loginUser();
    void logoutUser();
    void createPost();
    void viewPosts();
    void viewNewsFeed();
    void viewUserProfile();
    void connectWithUser();
    void shareTextContent();
    void shareImageContent();
    void searchUsers();
    void menu();
    void postUpdate();
    void updateProfile();
    void addFriend(User* user);
    void displayProfile();
    void discoverFriend();
    void displayFriendList() const;
//    void viewFriendPosts();
    void friend_Menu();
    void postMenu();
    void loadFriends(User*);
    void updateProfileDescription();

//    void loadFriendsdata();
    void saveData();
    void loadData();
    void loadPosts();
    void deletePosts();
    void savePosts();
//    bool isFriendSM(User* user);
    std::vector<User*> friends;
    std::vector<User*> users;
    std::vector<Post*> posts;
    std::vector<Post*> newsFeed;

bool isFriendOfLoggedInUser(User* user) const;
    int loggedInUserIndex = -1;
//    FriendManager friendManager;
User* getUserByUsername(const std::string& username);
void save_Data()const;
void load_Data();
User* getUserById(int id) const;
 User* getFriendById(const User* user, int id) const;
};

