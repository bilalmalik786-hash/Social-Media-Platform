#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <limits>
#include <sstream>
#include <cstddef>
#include "source.h"
#include <iterator> 
#include <conio.h> // Include this header for getch()
#include <algorithm> 

 int User:: getId() const {
        return id;
    }

void User:: setId(int value) {
    id = value;
}

 void User:: addFriend(User* user) {
        if (std::find(friends.begin(), friends.end(), user) == friends.end()) {
            friends.push_back(user);
            std::cout << username << " added " << user->getUsername() << " as a friend." << std::endl;
        } else {
            std::cout << username << " is already friends with " << user->getUsername() << "." << std::endl;
        }
    }

  void User:: displayFriendList() const {
    if (friends.empty()) {
        std::cout << getUsername() << " has no friends." << std::endl;
    } else {
        std::cout << getUsername() << "'s Friend List:" << std::endl;
        for (size_t i = 0; i < friends.size(); ++i) {
            std::cout << "- " << friends[i]->getUsername() << std::endl;
        }
    }
}

Post::Post(User* user, const std::string& content)
    : user(user), content(content) {}

User* Post::getUser() const {
    return user;
}

void Post::display() {
    std::cout << "Content: " << content << std::endl;
    std::cout << "Posted by: " << user->getUsername() << std::endl;
}

std::string Post::getContent() const {
    return content;
}

void Post::setContent(const std::string& newContent) {
    content = newContent;
}










std::vector<User*> User::getFriends()const {
    return friends;
}

   int User:: getIdCounter() {
        static int idCounter = 0;
        return idCounter;
    }

   void User:: setIdCounter(int value) {
        idCounter = value;
    }
    
    int User::idCounter = 0;
    
    
    
    
    
   User::User(const std::string& username, const std::string& password, const std::string& interests, const std::string& location, const std::string& popularThings)
    : username(username), password(password), interests(interests), location(location), popularThings(popularThings) {
    id = ++idCounter;
}




std::string User::getUsername() const {
    return username;
}

std::string User::getPassword() const {
    return password;
}

std::string User::getInterests() const {
    return interests;
}

std::string User::getLocation() const {
    return location;
}

std::string User::getPopularThings() const {
    return popularThings;
}

void toggleEcho(bool enableEcho) {
    HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
    DWORD mode;
    GetConsoleMode(hStdin, &mode);

    if (enableEcho)
        mode |= ENABLE_ECHO_INPUT;
    else
        mode &= ~ENABLE_ECHO_INPUT;

    SetConsoleMode(hStdin, mode);
}

void User::setUsername(const std::string& username) {
    this->username = username;
}

void User::setPassword(const std::string& password) {
    this->password = password;
}

void User::setInterests(const std::string& interests) {
    this->interests = interests;
}

void User::setLocation(const std::string& location) {
    this->location = location;
}

void User::setPopularThings(const std::string& popularThings) {
    this->popularThings = popularThings;
}

void User::displayProfile() const {
	
	std::cout << "\t\t*-User Profile-* " << std::endl;
    std::cout << "\tUsername: " << username << std::endl;
    std::cout << "\tPassword: ********" << std::endl;
    std::cout << "\tInterests: " << interests << std::endl;
    std::cout << "\tLocation: " << location << std::endl;
    std::cout << "\tPopular Things: " << popularThings << std::endl;
}


void User::connectWith(User& otherUser) {
    std::cout << username << " is now connected with " << otherUser.getUsername() << std::endl;
}

void User::shareTextContent(const std::string& content) {
    std::cout << username << " shared text content: " << content << std::endl;
}



void User::receiveTextContent(const User& sender, const std::string& content) {
    std::cout << "Received text content from " << sender.getUsername() << ": " << content << std::endl;
}

void User::postUpdate(const std::string& update) {
    std::cout << username << " posted an update: " << update << std::endl;
}

void User::setProfileDescription(const std::string& description) {
    profileDescription = description;
}

std::string User::getProfileDescription() const {
    return profileDescription;
}



void SocialMediaPlatform::run() {
    loadData();
    loadPosts();
   
    bool exit = false;
    int choice;
load_Data();


    while (!exit) {
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "\t\t\t\tSocial Media Platform" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "\t\t\t\t1. Create User" << std::endl;
        std::cout << "\t\t\t\t2. Login" << std::endl;
        std::cout << "\t\t\t\t3. Exit" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "Enter your choice: ";

        if (!(std::cin >> choice)) {
            std::cout << "Invalid input. Please enter a number." << std::endl;
            std::cin.clear();  // Clear the error state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Clear the input buffer
            continue;  // Restart the loop
        }

        std::cout << std::endl;

        switch (choice) {
        case 1:
            createUser();
            break;
        case 2:
            loginUser();
            break;
        case 3:
            exit = true;
            save_Data();
            savePosts();
            std::cout << "\t\t*----------------------Exiting the program--------------------*" << std::endl;
            std::cout << "\t\t*-------------------------Thanks Alot-----------------------*" << std::endl;
            break;
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
        }

        std::cout << std::endl;
    }

    saveData();
    
    deletePosts();
}
void SocialMediaPlatform::saveData() {
    std::ofstream file("user_data.txt");

    if (file.is_open()) {
        for (size_t i = 0; i < users.size(); i++) {
            User* user = users[i];
            file << user->getUsername() << "," << user->getPassword() << "," << user->getInterests() << "," << user->getLocation() << "," << user->getPopularThings() << std::endl;
        }

        file.close();
    }
    else {
        std::cout << "Unable to open the file for saving user data." << std::endl;
    }
 
}




void SocialMediaPlatform::loadData() {
    std::ifstream file("user_data.txt");

    if (file.is_open()) {
        std::string line;
        while (std::getline(file, line)) {
            std::string username, password, interests, location, popularThings;
            size_t commaPos1 = line.find(',');
            size_t commaPos2 = line.find(',', commaPos1 + 1);
            size_t commaPos3 = line.find(',', commaPos2 + 1);
            size_t commaPos4 = line.find(',', commaPos3 + 1);

            if (commaPos1 != std::string::npos && commaPos2 != std::string::npos && commaPos3 != std::string::npos && commaPos4 != std::string::npos) {
                username = line.substr(0, commaPos1);
                password = line.substr(commaPos1 + 1, commaPos2 - commaPos1 - 1);
                interests = line.substr(commaPos2 + 1, commaPos3 - commaPos2 - 1);
                location = line.substr(commaPos3 + 1, commaPos4 - commaPos3 - 1);
                popularThings = line.substr(commaPos4 + 1);

                bool userExists = false;
                for (size_t i = 0; i < users.size(); i++) {
                    User* existingUser = users[i];
                    if (existingUser->getUsername() == username) {
                        userExists = true;
                        break;
                    }
                }

                if (!userExists) {
                    User* newUser = new User(username, password, interests, location, popularThings);
                    users.push_back(newUser);
                }
            }
        }
        loadPosts();
    }
    else {
        std::cout << "No existing user data found." << std::endl;
    }
}

void SocialMediaPlatform::loadPosts() {
    if (!posts.empty()) {
        return;
    }

    std::ifstream file("post.txt");
    if (file.is_open()) {
        std::string line;
        while (std::getline(file, line)) {
            std::istringstream iss(line);
            std::string username, content;
            if (std::getline(iss, username, ',') && std::getline(iss, content)) {
                for (size_t i = 0; i < users.size(); i++) {
                    User* user = users[i];
                    if (user->getUsername() == username) {
                        Post* newPost = new Post(user, content);
                        posts.push_back(newPost);
                        newsFeed.push_back(newPost);
                        break;
                    }
                }
            }
        }
        file.close();
    }
    else {
        std::cout << "No existing post data found." << std::endl;
    }
}

void SocialMediaPlatform::savePosts() {
    std::ofstream file("post.txt");
    if (file.is_open()) {
        for (size_t i = 0; i < posts.size(); i++) {
            Post* post = posts[i];
            file << post->getUser()->getUsername() << "," << post->getContent() << std::endl;
        }
        file.close();
    }
    else {
        std::cout << "Unable to open file." << std::endl;
    }
}

void SocialMediaPlatform::deletePosts() {
    for (size_t i = 0; i < posts.size(); i++) {
        Post* post = posts[i];
        delete post;
    }
    posts.clear();
    newsFeed.clear();
}

void SocialMediaPlatform::createUser() {
    std::string username, password, interests, location, popularThings;
    std::cout << "\t\t*-Wellcome to Sign up Page-* " << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    
    std::cout << "\tEnter username: ";
    std::getline(std::cin, username);

    // Check if the username already exists
    for (size_t i = 0; i < users.size(); i++) {
        User* user = users[i];
        if (user->getUsername() == username) {
            std::cout << "Username already exists. Please try another username." << std::endl;
            return;  // Exit the function
        }
    }

    std::cout << "\tEnter password: ";
    toggleEcho(false);
    std::getline(std::cin, password);
    toggleEcho(true);

    std::cout << "\n\tEnter interests: ";
    std::getline(std::cin, interests);
    std::cout << "\tEnter location: ";
    std::getline(std::cin, location);
    std::cout << "\tEnter popular things: ";
    std::getline(std::cin, popularThings);

    User* newUser = new User(username, password, interests, location, popularThings);
    users.push_back(newUser);

    std::cout << "\n\n\t\t*-User created successfully!-*" << std::endl;
}

void SocialMediaPlatform::loginUser() {
    std::string username, password;
    std::cout << "\t\t*-Wellcome to Login Page-* " << std::endl;
    std::cout << "\tEnter username: ";
    std::cin >> username;
    std::cout << "\n\tEnter password: ";
    toggleEcho(false);
    std::cin >> password;
    toggleEcho(true);

    for (size_t i = 0; i < users.size(); i++) {
        User* user = users[i];
        if (user->getUsername() == username && user->getPassword() == password) {
            loggedInUserIndex = i;
            std::cout << "\n\n\t\t*-Login successful!-*" << std::endl;

             menu();// function here if implemented
            return;
        }
    }

    std::cout << "\n\t*-Invalid username or password. Login failed-*" << std::endl;
    loggedInUserIndex = -1;

    // After unsuccessful login, go back to the main menu
     run(); //function here if implemented
}


void SocialMediaPlatform::logoutUser() {
    loggedInUserIndex = -1;
    std::cout << "\n\t\t*-Logout successful!-*" << std::endl;
}

void SocialMediaPlatform::createPost() {
	    std::cout << "\t\t*-Wellcome to Create Post-* " << std::endl;
    if (loggedInUserIndex != -1) {
        User* currentUser = users[loggedInUserIndex];
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "\n\tEnter post content: ";
        std::string content;
        std::getline(std::cin, content);

        Post* newPost = new Post(currentUser, content);
        posts.push_back(newPost);
        newsFeed.push_back(newPost);

        std::cout << "\n\t\t*-Post created successfully!-*" << std::endl;
    }
    else {
        std::cout << "\n\t\tYou need to login first to create a post." << std::endl;
    }
}

void SocialMediaPlatform::viewPosts() {
    if (loggedInUserIndex != -1) {
        User* currentUser = users[loggedInUserIndex];
        std::cout << "\n\tPosts by " << currentUser->getUsername() << ":" << std::endl;
        bool foundPosts = false;

        for (size_t i = 0; i < posts.size(); i++) {
            Post* post = posts[i];
            if (post->getUser() == currentUser) {
                post->display();
                std::cout << std::endl;
                foundPosts = true;
            }
        }

        if (!foundPosts) {
            std::cout << "\n\t*-No posts found-*" << std::endl;
        }
    }
    else {
        std::cout << "\n\t\t*-You need to login first to view posts-*" << std::endl;
    }
}

void SocialMediaPlatform::viewNewsFeed() {
	std::cout << "\t\t*-Wellcome to News Feed Page-* " << std::endl;
    if (!newsFeed.empty()) {
        std::cout << "\n\t*-News Feed-*" << std::endl;
        for (size_t i = 0; i < newsFeed.size(); i++) {
            Post* post = newsFeed[i];
            post->display();
            std::cout << std::endl;
        }
    }
    else {
        std::cout << "\n\t\t*-No posts found in the news feed-*" << std::endl;
    }
}

void SocialMediaPlatform::viewUserProfile() {
    if (loggedInUserIndex != -1) {
        users[loggedInUserIndex]->displayProfile();
    }
    else {
        std::cout << "You need to login first to view the user profile." << std::endl;
    }
}

void SocialMediaPlatform::connectWithUser() {
	std::cout << "\t\t*-Wellcome to connect With User Page-* " << std::endl;
    if (loggedInUserIndex != -1) {
        std::string username;
        std::cout << "\n\tEnter the username of the user you want to connect with: ";
        std::cin >> username;

        for (size_t i = 0; i < users.size(); i++) {
            User* user = users[i];
            if (user->getUsername() == username) {
                users[loggedInUserIndex]->connectWith(*user);
                return;
            }
        }

        std::cout << "\n\tUser with the username '" << username << "' not found." << std::endl;
    }
    else {
        std::cout << "\n\t*-You need to login first to connect with a user-*" << std::endl;
    }
}

void SocialMediaPlatform::shareTextContent() {
	std::cout << "\t\t*-Wellcome to share Text Content Page-* " << std::endl;
    if (loggedInUserIndex != -1) {
        std::string content;
        std::cout << "\n\tEnter the text content you want to share: ";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::getline(std::cin, content);

        users[loggedInUserIndex]->shareTextContent(content);
    }
    else {
        std::cout << "\n\t*-You need to login first to share text content-*" << std::endl;
    }
}


void SocialMediaPlatform::postUpdate() {
    if (loggedInUserIndex != -1) {
        std::cout << "Your Posts:" << std::endl;
        int postCount = 1;
        std::vector<Post*> userPosts;  // Store the posts of the logged-in user
        for (size_t i = 0; i < posts.size(); i++) {
            Post* post = posts[i];
            if (post->getUser() == users[loggedInUserIndex]) {
                std::cout << postCount << ". ";
                post->display();
                std::cout << std::endl;
                userPosts.push_back(post);
                postCount++;
            }
        }

        if (postCount == 1) {
            std::cout << "You have no posts to update." << std::endl;
            return;
        }

        int selectedPostIndex;
        bool validInput = false;  // Flag to check if the input is valid
        do {
            std::cout << "Enter the index of the post you want to update: ";
            std::cin >> selectedPostIndex;

            if (selectedPostIndex >= 1 && selectedPostIndex <= postCount - 1) {
                validInput = true;
            }
            else {
                std::cout << "Invalid post index. Please try again." << std::endl;
            }

            // Clear the input buffer
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        } while (!validInput);

        std::cout << "Enter the updated content: ";
        std::string updatedContent;
        std::getline(std::cin, updatedContent);

        Post* selectedPost = userPosts[selectedPostIndex - 1];
        selectedPost->setContent(updatedContent);

        // Update the post in the newsFeed vector as well
        for (size_t i = 0; i < newsFeed.size(); i++) {
            Post* newsPost = newsFeed[i];
            if (newsPost == selectedPost) {
                newsPost->setContent(updatedContent);
                break;
            }
        }

        std::cout << "Post updated successfully!" << std::endl;
    }
    else {
        std::cout << "You need to login first to post an update." << std::endl;
    }
}

void SocialMediaPlatform::updateProfile() {
    if (loggedInUserIndex != -1) {
        std::string username, password, interests, location, popularThings;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Enter username: ";
        std::getline(std::cin, username);

        for (size_t i = 0; i < users.size(); i++) {
            User* user = users[i];
            if (user->getUsername() == username) {
                std::cout << "Username already exists. Please try another username." << std::endl;
                return;  // Exit the function
            }
        }

        std::cout << "Enter password: ";
        std::getline(std::cin, password);
        std::cout << "Enter interests: ";
        std::getline(std::cin, interests);
        std::cout << "Enter location: ";
        std::getline(std::cin, location);
        std::cout << "Enter popular things: ";
        std::getline(std::cin, popularThings);

        users[loggedInUserIndex]->setUsername(username);
        users[loggedInUserIndex]->setPassword(password);
        users[loggedInUserIndex]->setInterests(interests);
        users[loggedInUserIndex]->setLocation(location);
        users[loggedInUserIndex]->setPopularThings(popularThings);

        std::cout << "User profile updated successfully!" << std::endl;
    }
    else {
        std::cout << "You need to log in first to update your profile." << std::endl;
    }
}

void SocialMediaPlatform::updateProfileDescription() {
    if (loggedInUserIndex != -1) {
        User* currentUser = users[loggedInUserIndex];
        std::cout << "Enter the new profile description (or 'exit' to cancel): ";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::string description;
        std::getline(std::cin, description);

        if (description == "exit") {
            return;
        }

        currentUser->setProfileDescription(description);
        std::cout << "Profile description updated successfully!" << std::endl;
    }
    else {
        std::cout << "You need to login first to update your profile." << std::endl;
    }
}


void SocialMediaPlatform::displayProfile() {
    if (loggedInUserIndex != -1) {
        std::string username;
        std::cout << "Enter the username of the user whose profile you want to display (or 'exit' to cancel): ";
        std::cin >> username;

        if (username == "exit") {
            return;
        }

        for (std::vector<User*>::iterator it = users.begin(); it != users.end(); ++it) {
            User* user = *it;
            if (user->getUsername() == username) {
                user->displayProfile();
                return;
            }
        }

        std::cout << "User with the username '" << username << "' not found." << std::endl;
    }
    else {
        std::cout << "You need to login first to display a profile." << std::endl;
    }
}


void SocialMediaPlatform::discoverFriend() {
    if (loggedInUserIndex != -1) {
        User* loggedInUser = users[loggedInUserIndex];
        bool foundNewFriends = false;

        std::cout << "Users that you can add as friends:" << std::endl;
        for (int i = 0; i < users.size(); i++) {
            User* user = users[i];
            if (user != loggedInUser && !isFriendOfLoggedInUser(user)) {
                std::cout << i + 1 << ". " << user->getUsername() << std::endl;
                foundNewFriends = true;
            }
        }

        if (!foundNewFriends) {
            std::cout << "No users available to add as friends." << std::endl;
        } else {
            int friendIndex;
            std::cout << "Enter the index of the user you want to add as a friend (or 0 to cancel): ";
            std::cin >> friendIndex;

            if (friendIndex > 0 && friendIndex <= users.size() && friendIndex != loggedInUserIndex) {
                User* friendUser = users[friendIndex - 1];
                loggedInUser->addFriend(friendUser);
            } else if (friendIndex == 0) {
                std::cout << "Friend adding canceled." << std::endl;
            } else {
                std::cout << "Invalid user index." << std::endl;
            }
        }
    } else {
        std::cout << "Please login to discover new friends." << std::endl;
    }
}

bool SocialMediaPlatform::isFriendOfLoggedInUser(User* user) const {
    User* loggedInUser = users[loggedInUserIndex];
    return std::find(loggedInUser->friends.begin(), loggedInUser->friends.end(), user) != loggedInUser->friends.end();
}


void SocialMediaPlatform::addFriend(User* user) {
    std::cout << "Logged-in User: " << user->getUsername() << std::endl;
    std::cout << "Accounts available to add as friends:" << std::endl;

    for (int i = 0; i < users.size(); i++) {
        if (users[i] != user) {
            std::cout << i + 1 << ". " << users[i]->getUsername() << std::endl;
        }
    }

    int friendIndex;
    std::cout << "Enter the index of the user you want to add as a friend (or 0 to cancel): ";
    std::cin >> friendIndex;

    if (friendIndex > 0 && friendIndex <= users.size() && users[friendIndex - 1] != user) {
        User* friendUser = users[friendIndex - 1];
        user->addFriend(friendUser);
    } else if (friendIndex == 0) {
        std::cout << "Friend adding canceled." << std::endl;
    } else {
        std::cout << "Invalid user index." << std::endl;
    }

    std::cout << std::endl;

    // Display friend list after adding the new friend
    user->displayFriendList();
}



void SocialMediaPlatform::displayFriendList() const {
    if (loggedInUserIndex != -1) {
        User* loggedInUser = users[loggedInUserIndex];
        loggedInUser->displayFriendList();
    } else {
        std::cout << "Please login to view friend list." << std::endl;
    }
}

void SocialMediaPlatform::save_Data() const {
    std::ofstream outputFile("dataFriend.txt");
    if (outputFile.is_open()) {
        // Save user data
        outputFile << users.size() << std::endl;
        for (size_t i = 0; i < users.size(); ++i) {
            const User* user = users[i];
            outputFile << user->getId() << " "
                       << user->getUsername() << " "
                       << user->getPassword() << " "
                       << user->getInterests() << " "
                       << user->getLocation() << " "
                       << user->getPopularThings() << std::endl;

            // Save friend list for each user
            const std::vector<User*> friendsList = user->getFriends();
            outputFile << friendsList.size() << " ";
            for (size_t j = 0; j < friendsList.size(); ++j) {
                const User* friendUser = friendsList[j];
                outputFile << friendUser->getId() << " "; // Save friend's ID
            }
            outputFile << std::endl;
        }

        outputFile.close();
    } else {
        std::cerr << "Error: Unable to save data to file." << std::endl;
    }
}


 User* SocialMediaPlatform::getUserById(int id) const {
    for (size_t i = 0; i < users.size(); ++i) {
        if (users[i]->getId() == id) {
            return users[i];
        }
    }
    return 0; // User with the given ID not found
}

    User* SocialMediaPlatform::getFriendById(const User* user, int id) const {
    for (size_t i = 0; i < user->friends.size(); ++i) {
        if (user->friends[i]->getId() == id) {
            return user->friends[i];
        }
    }
    return 0; // Friend with the given ID not found
}


// Add this function to the SocialMediaPlatform class
User* SocialMediaPlatform::getUserByUsername(const std::string& username) {
    for (size_t i = 0; i < users.size(); ++i) {
        if (users[i]->getUsername() == username) {
            return users[i];
        }
    }
    return 0; // Return nullptr if no user with the given username is found
}

void SocialMediaPlatform::load_Data() {
    std::ifstream inputFile("dataFriend.txt");
    if (inputFile.is_open()) {
        int numUsers;
        inputFile >> numUsers;

        int maxId = 0; // Track the maximum ID in the loaded data

        for (int i = 0; i < numUsers; ++i) {
            int id;
            std::string username, password, interests, location, popularThings;
            inputFile >> id >> username >> password >> interests >> location >> popularThings;

            // Check if a user with the same ID or username already exists
            User* existingUser = getUserById(id);
            if (!existingUser) {
                existingUser = getUserByUsername(username);
            }

            if (!existingUser) {
                // Create a new user instance only if no existing user is found
                User* newUser = new User(username, password, interests, location, popularThings);
                newUser->setId(id); // Set the ID for the user
                users.push_back(newUser);
                existingUser = newUser;
            }

            // Load friend list for each user
            int numFriends;
            inputFile >> numFriends;
            for (int j = 0; j < numFriends; ++j) {
                int friendId;
                inputFile >> friendId;
                User* friendUser = getUserById(friendId); // Helper function to find friend by ID
                if (friendUser) {
                    existingUser->addFriend(friendUser);
                }
            }

            // Update maxId
            if (id > maxId) {
                maxId = id;
            }
        }

        User::setIdCounter(maxId + 1); // Increment idCounter to the next available ID

        inputFile.close();
    } else {
        std::cerr << "Error: Unable to open data file." << std::endl;
    }
}




void SocialMediaPlatform::menu() {
    bool exit = false;
    int choice;

    while (!exit && loggedInUserIndex != -1) {

        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "\t\t\t\t\tMain Menu" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "\t\t\t\t1. Logout" << std::endl;
        std::cout << "\t\t\t\t2. Post" << std::endl;
        std::cout << "\t\t\t\t3. View News Feed" << std::endl;
        std::cout << "\t\t\t\t4. View User Profile" << std::endl;
        std::cout << "\t\t\t\t5. Connect with User" << std::endl;
        std::cout << "\t\t\t\t6. Share Text Content" << std::endl;
        //std::cout << "\t\t\t\t7. Share Image Content" << std::endl;
        std::cout << "\t\t\t\t7. Update Profile" << std::endl;
        std::cout << "\t\t\t\t8. Friend" << std::endl;
        std::cout << "\t\t\t\t9. Return to Main Menu" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "Enter your choice: ";
        if (!(std::cin >> choice)) {
            std::cout << "Invalid input. Please enter a number." << std::endl;
            std::cin.clear();  // Clear the error state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Clear the input buffer
            continue;  // Restart the loop
        }
        std::cout << std::endl;

        switch (choice) {
        case 1:
            logoutUser();
            break;
        case 2:
            postMenu();
            break;

        case 3:
            viewNewsFeed();
            break;
        case 4:
            viewUserProfile();
            break;
        case 5:
            connectWithUser();
            break;
        case 6:
            shareTextContent();
            break;
//        case 7:
//            shareImageContent();
//            break;

        case 7:
            updateProfile();
            break;
        case 8:
            friend_Menu();
            break;

        case 9:
            std::cout << "Returning to the Login page..." << std::endl;
            return;

        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
        }

        std::cout << std::endl;
    }
}


void SocialMediaPlatform::postMenu() {
    bool exit = false;
    int choice;

    while (!exit && loggedInUserIndex != -1) {

        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "\t\t\t\t\tPost Menu" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "\t\t\t\t1. Create Post" << std::endl;
        std::cout << "\t\t\t\t2. View Posts" << std::endl;
        std::cout << "\t\t\t\t3. Update Post" << std::endl;
        std::cout << "\t\t\t\t4. Return to Main Menu" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "Enter your choice: ";
        if (!(std::cin >> choice)) {
            std::cout << "Invalid input. Please enter a number." << std::endl;
            std::cin.clear();  // Clear the error state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Clear the input buffer
            continue;  // Restart the loop
        }
        std::cout << std::endl;

        switch (choice) {
        case 1:
            createPost();
            break;
        case 2:
            viewPosts();
            break;
        case 3:
            postUpdate();
            break;
        case 4:
            std::cout << "Returning to the main menu..." << std::endl;
            return;

        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
        }

        std::cout << std::endl;
    }
}

void SocialMediaPlatform::friend_Menu() {
    bool exit = false;
    int choice;

    while (!exit && loggedInUserIndex != -1) {

        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "\t\t\t\t\tFriend Menu" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;

        std::cout << "\t\t\t\t1. Add Friend" << std::endl;
        std::cout << "\t\t\t\t2. Display Profile" << std::endl;
        std::cout << "\t\t\t\t3. Discover Friends" << std::endl;
        std::cout << "\t\t\t\t4. Display Friends List" << std::endl;

        std::cout << "\t\t\t\t5. Return to Main Menu" << std::endl;
        std::cout << "\t\t\t\t-------------------------" << std::endl;
        std::cout << "Enter your choice: ";
        if (!(std::cin >> choice)) {
            std::cout << "Invalid input. Please enter a number." << std::endl;
            std::cin.clear();  // Clear the error state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Clear the input buffer
            continue;  // Restart the loop
        }
        std::cout << std::endl;

        switch (choice) {
            // Existing cases...

        case 1:
            addFriend(users[loggedInUserIndex]);
            break;
        case 2:
            displayProfile();
            break;
        case 3:
            discoverFriend();
            break;
        case 4:
            displayFriendList();
            break;
        case 5:
            std::cout << "Returning to the main menu..." << std::endl;
            return;

        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
        }

        std::cout << std::endl;
    }
}










