#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <limits>
#include <sstream>
#include <cstdlib>
#include "source.h"
#include <windows.h>
#include <cstddef>
#include <iterator>
#include <algorithm>  
int main() {
    system("color 7D");
    system("cls");
    SocialMediaPlatform platform;
    platform.run();

    return 0;
}
